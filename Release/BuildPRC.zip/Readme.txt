BuildPRC - .prc generator for PocketC
      Copyright 1999 OrbWorks
-------------------------------------
This software creates a stub program that will allow an applet to be launched from the
Application launcher. It also allows the user to import bitmaps for both the large
and small icons. (Small icons are only visible on Palm III).

The generated .prc will still require PocketC 2.0 or greater to be present (either the
standard compiler or the runtime only edition), and the original applet .pdb file.

Since the generated applets only work with version 2.0 (they will cause version 1.0 to
hang) please include a copy of PocketC_rt.zip with your applet.

If you intend to distribute your applet's .prc, you MUST register the creator ID with
Palm Computing.

IMPORTANT: BuildPRC is only available to registered PocketC users. DO NOT DISTRIBUTE!

---------------------------------------------------------------------------------------

BuildPRC - Copyright 1999 OrbWorks

   Source      - the source .pdb file
   Output      - the desired .prc output file
   Large icon  - a 256 color 32x22 BMP file (sample included)
   Small icon  - a 256 color 16x9 BMP file (sample included)
   Version     - a short version number string (e.g. 1.0)
   Name        - the name of your applet (as displayed in PocketC - CASE SENSITIVE!)
   Creator ID  - the 4-char creator ID you've registered with Palm Computing
