PocketC Desktop Edition
Retail Version
(c) 1997-2006 OrbWorks
-----------------------

Sales Pitch:
  PocketC Desktop Edition makes it possible to create PocketC applets on
  a PC, allowing for rapid development and testing in combination with
  the Palm OS Emulator. PDE is capable of producing a standard applet
  database or a .prc with the applet code embedded. PocketC is still
  required on the target device.

Feedback:
  Report bugs, comments, and suggestions to Jeremy Dewey (dewey@orbworks.com)

Legal Stuff:
  This software is provided as is, with no guarantee of fitness for any
  particular task. The user assumes all responsibility for its use.

  THIS IS A COMMERCIAL PRODUCT -- PLEASE DO NOT DISTRIBUTE.