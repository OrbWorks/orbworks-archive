// Date/Time sample

main() {
   puts("Ticks:\t\t" + ticks() + "\n");
   puts("Seconds:\t\t" + seconds() + "\n");
   puts("Time Int:\t\t" + time(0) + "\n");
   puts("Time Str:\t\t" + time(1) + "\n");
   puts("Date Int:\t\t" + date(0) + "\n");
   puts("Date Str:\t\t" + date(1) + "\n");
   puts("Date Long:\t" + date(2) + "\n");
}