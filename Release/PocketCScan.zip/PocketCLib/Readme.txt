PocketCLib
----------
This is a sample with three fairly useless functions:

  times5(int x) - returns x * 5
  reverse(string str) - returns the string str reversed (e.g. "reversed" -> "desrever")
  volume(float x, float y, float z) - returns x*y*z
