   PocketC v7.1rt
   Copyright 1997-2007, OrbWorks
   http://www.orbworks.com/
---------------------------------------
PocketC is a PalmOS-based C compiler. This, however, is a freeware runtime-only
version. For information regarding the full version, which allows you to write
and compile your own applets, visit our website.

PocketC only works with OS 2.0 and up.

Installation:
-------------
Using your favorite PalmPilot program, install PocketC.prc. Additionally, you
may also install MathLib.prc (which adds a substantial number of floating-
point functions such as trig functions). This runtime version will replace any
other installed version of PocketC.

Files included:
---------------
PocketC.prc      The PocketC application
MathLib.prc      The free math shared library. See MathLib.txt for details.
                 Note: MathLib is not required, but provides additional
                       floating point functions.
MathLib.txt      Readme for MathLib, explains licensing, etc.
Readme.txt       This file.

Contact:
--------
Please bug reports to Jeremy Dewey (dewey@orbworks.com).

Legal:
------
This software is provided as is, with no guarantee of fitness for any particular
task. The user assumes all responsibility for its use.