// Hello, World
main() {
   alert("Hello, World");
}
