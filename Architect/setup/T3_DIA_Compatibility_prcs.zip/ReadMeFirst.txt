These are the Dynamic Input area compatibility prcs that are needed on the Tungsten T3 device to be compatible with the PalmSource Dynamic Input Area APIs. Please install these on your device via HotSync if you want to run application that uses the Palm DIA APIs.

IMPORTANT - You must install both prcs at the same time; installing them seperately may force a hard reset.
